# Bloom starter prototype

A single-file, responsive lifestyle organizer prototype.

## How to run
- Open `index.html` in a modern web browser.
- On a computer, double-click the file.
- On a phone, the easiest route is to publish it to a static web host and open the URL.

## Included
- Responsive layout for phone and desktop
- Dashboard
- Add, complete, and delete tasks
- Add and check habits
- Add goals and adjust progress
- Create, edit, and delete notes
- Browser localStorage persistence

## Important limitations
- Data is saved only in the current browser on the current device.
- There are no accounts, cloud sync, notifications, or secure multi-user storage.
- This is a prototype, not a production-ready app.
- The name “Bloom” is a working name; check naming and trademark availability before commercial launch.

## Publish with GitHub Pages
1. Create a GitHub account if needed.
2. Create a new repository (for example, `bloom-organizer`).
3. Upload `index.html` to the repository root.
4. Open repository Settings → Pages.
5. Choose “Deploy from a branch”, select `main` and `/ (root)`, then save.
6. Wait for the published URL to appear in the Pages section.

Publishing makes the site publicly accessible. Do not store sensitive personal information in this prototype.
